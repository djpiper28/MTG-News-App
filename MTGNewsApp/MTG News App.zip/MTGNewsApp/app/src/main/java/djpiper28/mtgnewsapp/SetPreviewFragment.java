package djpiper28.mtgnewsapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;

import java.util.Calendar;

import forohfor.scryfall.api.Set;

public class SetPreviewFragment extends Fragment {

    private Set set;

    public SetPreviewFragment(Set set) {
        this.set = set;
    }

    public static SetPreviewFragment newInstance(Set set) {
        SetPreviewFragment fragment = new SetPreviewFragment(set);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_set_preview, container, false);

        ImageView setImage = view.findViewById(R.id.SetIcon);

        Glide
                .with(this)
                .load(set.getSetIconURI())
                .centerCrop()
                .placeholder(R.drawable.reload)
                .into(setImage);

        TextView titleText = view.findViewById(R.id.SetTitle);
        titleText.setText(set.getName());

        TextView releaseDate = view.findViewById(R.id.ReleaseDate);

        releaseDate.setText(set.getReleasedAt().toInstant().toString());

        Button viewPreviews = view.findViewById(R.id.OpenSetPreviews);
        viewPreviews.setOnClickListener(event -> {
            
        });

        return view;
    }
}
