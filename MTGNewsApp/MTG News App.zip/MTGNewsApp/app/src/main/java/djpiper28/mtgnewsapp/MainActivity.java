package djpiper28.mtgnewsapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import androidx.fragment.app.Fragment;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.LinkedList;
import java.util.List;

import djpiper28.news.NewsItem;

import static djpiper28.mtgnewsapp.loadingScreen.news;

public class MainActivity extends Fragment {

    private List<Fragment> fragments;
    private int loadedItems;

    private Fragment getFragmentForNewsItem(NewsItem newsItem) {
        return newsFragment.newInstance(newsItem);
    }

    private void addFragment(Fragment fragment) {
        getChildFragmentManager().beginTransaction().add(R.id.scrollContainer, fragment).commit();
    }

    private void loadNews(View view) {
        loadedItems = 0;

        loadMore(view);
    }

    private void loadMore(View view) {
        for (int i = 0; (i < 20) && loadedItems < news.size(); i++) {
            Fragment fragment = getFragmentForNewsItem(news.get(loadedItems));
            fragments.add(fragment);
            addFragment(fragment);
            loadedItems++;
        }

        if (loadedItems == news.size()) {
            Button button = view.findViewById(R.id.loadMore);
            button.setText("See Article Archive");
            button.setOnClickListener(event -> {
                String url = "https://magic.wizards.com/en/articles/archive";
                Intent intent = new Intent(getActivity(), ArticleViewActivity.class);
                ArticleViewActivity.urlForArticle = url;
                startActivity(intent);
            });
        }
    }

    private void refreshNews() {
        Intent intent = new Intent(getActivity(), loadingScreen.class);
        startActivity(intent);
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_main, container, false);

        fragments = new LinkedList<>();
        loadNews(view);

        Button loadMore = view.findViewById(R.id.loadMore);
        loadMore.setOnClickListener(event -> {
            loadMore(view);
        });

        FloatingActionButton refresh = view.findViewById(R.id.fab);
        refresh.setOnClickListener(event -> {
            refreshNews();
        });

        // Change padding if screen is small
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int height = displayMetrics.heightPixels;
        int width = displayMetrics.widthPixels;

        if(Math.sqrt(height*height + width*width) < 7){
            LinearLayout scrollContainer = view.findViewById(R.id.scrollContainer);
            scrollContainer.setPadding(5,5,5,5);
        }

        return view;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}