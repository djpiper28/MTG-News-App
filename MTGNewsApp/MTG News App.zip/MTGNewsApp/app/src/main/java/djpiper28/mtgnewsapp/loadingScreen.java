package djpiper28.mtgnewsapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import java.util.LinkedList;
import java.util.List;

import djpiper28.news.NewsGetter;
import djpiper28.news.NewsItem;
import forohfor.scryfall.api.Set;

public class loadingScreen extends AppCompatActivity {

    public static List<NewsItem> news;
    public static List<forohfor.scryfall.api.Set> sets;

    private void error(String errorMessage) {
        errorFragment fragmentActivity = errorFragment.newInstance(errorMessage);
        addFragment(fragmentActivity);
    }

    private void addFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction().add(R.id.errors, fragment).commit();
    }

    private List<NewsItem> loadNews() {
        List<NewsItem> news = new LinkedList<>();

        NewsGetter newsGetter = null;
        boolean gotNews = false;
        int a = 0;

        while (!gotNews && a < 5) {
            try {
                newsGetter = new NewsGetter();
                news = newsGetter.getNews();
                gotNews = true;
            } catch (final Exception e) {
                e.printStackTrace();

                // Wait and hope the internet starts to work after the wait
                try {
                    Thread.sleep(20);
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                    error(ex.toString());
                }
            }
            a++;
        }

        if (!gotNews || news == null) {
            error("Unable to download news");
        }

        a = 0;
        boolean gotSets = false;
        while (!gotSets && a < 5) {
            try {
                sets = forohfor.scryfall.api.MTGCardQuery.getSets();
                gotSets = true;
            } catch (final Exception e) {
                e.printStackTrace();

                // Wait and hope the internet starts to work after the wait
                try {
                    Thread.sleep(20);
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                    error(ex.toString());
                }
            }
            a++;
        }

        if (!gotSets || sets == null) {
            error("Unable to download sets");
        }

        return news;
    }

    @Override
    public void onBackPressed() {
        // Nothing!
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loading_screen);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.INTERNET)
                != PackageManager.PERMISSION_GRANTED) {
            Log.e("Error", "No permission to access internet");
            error("Error - no internet permission");
        } else {
            (new Thread(() -> {
                Log.i("Loading Screen", "Started loading");
                news = loadNews();
                Log.i("Loading Screen", "Finished loading");

                if(news != null && news.size() > 0 && sets != null && sets.size() > 0) {
                    Intent intent = new Intent(this, TabHost.class);
                    startActivity(intent);
                } else {
                    Log.i("Loading Screen", "Failed loading");
                    ProgressBar bar = findViewById(R.id.progressBar);
                    bar.setProgress(0);
                    error("Unable to load.");
                }

            })).start();
        }
    }
}
