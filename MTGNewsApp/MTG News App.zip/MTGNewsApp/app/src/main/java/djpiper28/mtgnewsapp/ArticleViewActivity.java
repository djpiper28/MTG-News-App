package djpiper28.mtgnewsapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class ArticleViewActivity extends AppCompatActivity {

    public static String urlForArticle = "djpiper82.mtgnewsapp.urlforarticleview";

    private void openLink(String url) {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(browserIntent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_article_view);

        String url = urlForArticle;
        WebView webView = findViewById(R.id.webView);
        try {
            webView.loadUrl(url);
        } catch (Exception e) {
            e.printStackTrace();
            webView.loadUrl("https://dailymtg.com/");
        }

        FloatingActionButton fab = findViewById(R.id.articleFab);
        fab.setOnClickListener(event -> {
            openLink(url);
        });
    }

}
