package djpiper28.mtgnewsapp;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.time.Instant;
import java.util.Calendar;
import java.util.List;

import forohfor.scryfall.api.Set;


public class NewAndUnReleasedSetsFragment extends Fragment {

    private List<Set> sets;

    private NewAndUnReleasedSetsFragment(List<Set> sets) {
        this.sets = sets;
    }

    public static NewAndUnReleasedSetsFragment newInstance() {
        NewAndUnReleasedSetsFragment fragment = new NewAndUnReleasedSetsFragment(loadingScreen.sets);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    private void addUnReleasedSet(forohfor.scryfall.api.Set set){
        SetPreviewFragment fragment = SetPreviewFragment.newInstance(set);
        getChildFragmentManager().beginTransaction().add(R.id.NewSets, fragment).commit();
    }

    private void addReleasedSet(forohfor.scryfall.api.Set set) {
        SetPreviewFragment fragment = SetPreviewFragment.newInstance(set);
        getChildFragmentManager().beginTransaction().add(R.id.UnreleasedSets, fragment).commit();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_new_and_un_released_sets, container, false);

        Instant now = Calendar.getInstance().toInstant();
        Instant twoWeeksAgo = Calendar.getInstance().toInstant();
        twoWeeksAgo.minusSeconds(14l*24l*36000l);

        for(forohfor.scryfall.api.Set set: sets) {
            if(set.getReleasedAt().toInstant().isAfter(now)) {
                addUnReleasedSet(set);
            } else if (set.getReleasedAt().toInstant().isAfter(twoWeeksAgo)) {
                addReleasedSet(set);
            } else{
                break;
            }
        }

        return view;
    }
}
