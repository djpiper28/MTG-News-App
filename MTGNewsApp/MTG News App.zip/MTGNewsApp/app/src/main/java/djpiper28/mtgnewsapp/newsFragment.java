package djpiper28.mtgnewsapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;

import java.io.IOException;

import djpiper28.news.NewsItem;

import static djpiper28.mtgnewsapp.ArticleViewActivity.urlForArticle;

public class newsFragment extends Fragment {

    private NewsItem newsItem;

    private newsFragment(NewsItem newsItem) {
        this.newsItem = newsItem;
    }

    public static newsFragment newInstance(NewsItem newsItem) {
        newsFragment fragment = new newsFragment(newsItem);
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_news, container, false);
        TextView title = (TextView) view.findViewById(R.id.title);
        TextView publishInfo = (TextView) view.findViewById(R.id.publishInfo);
        TextView articleText = (TextView) view.findViewById(R.id.articleText);

        title.setText(this.newsItem.getTitle());
        publishInfo.setText("Published on " + this.newsItem.getPublishedDate() + " by " + this.newsItem.getAuthor());
        articleText.setText(this.newsItem.getDescription());
        Button openArticle = view.findViewById(R.id.openArticle);
        openArticle.setOnClickListener(event -> {

            String url = newsItem.getLink();

            if (!url.startsWith("http://") && !url.startsWith("https://"))
                url = "http://" + url;

            Intent intent = new Intent(getContext(), ArticleViewActivity.class);
            urlForArticle = url;

            startActivity(intent);

            /*
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(browserIntent);
            */
        });

        ImageView myImageView = view.findViewById(R.id.backgroundImage);

        try {
            Glide
                    .with(this)
                    .load(newsItem.getImageURL().toString())
                    .centerCrop()
                    .transform(new RoundedCorners(24))
                    .placeholder(R.drawable.reload)
                    .into(myImageView);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Change padding if screen is small
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int height = displayMetrics.heightPixels;
        int width = displayMetrics.widthPixels;

        if(Math.sqrt(height*height + width*width) < 7){
            ConstraintLayout newsContainer = view.findViewById(R.id.newsContainer);
            newsContainer.setPadding(2,2,2,2);
            articleText.setMaxLines(4);
        }

        return view;
    }
}
