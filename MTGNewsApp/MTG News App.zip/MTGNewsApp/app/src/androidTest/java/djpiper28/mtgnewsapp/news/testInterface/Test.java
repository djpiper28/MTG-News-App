package djpiper28.mtgnewsapp.news.testInterface;

public abstract class Test {

    public abstract boolean executeTest();

    public abstract String getTestName();

}
